#!/bin/bash

rm -f *.json