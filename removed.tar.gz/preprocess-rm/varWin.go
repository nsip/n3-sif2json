// +build windows

package preprocess

const (
	execCmdName = "PowerShell"
	execCmdP0   = "-Command"
	jq          = "jq.exe"
)
