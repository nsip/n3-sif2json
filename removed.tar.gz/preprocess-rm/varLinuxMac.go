// +build linux darwin

package preprocess

const (
	execCmdName = "bash"
	execCmdP0   = "-c"
	jq          = "jq"
)
