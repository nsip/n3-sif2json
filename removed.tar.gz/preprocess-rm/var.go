package preprocess

import "fmt"

var (
	fPf = fmt.Printf
	fEf = fmt.Errorf
)
