#!/bin/bash

rm -f *.json
rm -rf ./utils ./build
